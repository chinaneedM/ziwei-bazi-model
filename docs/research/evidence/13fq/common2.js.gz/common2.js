
$(document).ready(function(){

	var map = "su";
	// 고지도 메인
	$('.gzd-map_select a').click(function(){
		map = $(this).attr("id");
		var jimyung;
		switch(map){
		//경북
		case "kb" : jimyung = "경상북도"; break;
		//경남
		case "kn" : jimyung = "경상남도"; break;
		//전북
		case "jb" : jimyung = "전라북도"; break;
		//전남
		case "jn" : jimyung = "전라남도"; break;
		//충북
		case "cb" : jimyung = "충청북도"; break;
		//충남
		case "cn" : jimyung = "충청남도"; break;
		//서울
		case "su" : jimyung = "서울특별시"; break;
		//경기
		case "kk" : jimyung = "경기도"; break;
		//강원
		case "kw" : jimyung = "강원도"; break;
		//황북
		case "hb" : jimyung = "황해북도"; break;
		//황남
		case "hn" : jimyung = "황해남도"; break;
		//평양
		case "py" : jimyung = "평양직할시"; break;				
		//평북
		case "pb" : jimyung = "평안북도"; break;				
		//평남
		case "pn" : jimyung = "평안남도"; break;
		//양강
		case "yk" : jimyung = "양강도"; break;
		//자강
		case "jk" : jimyung = "자강도"; break;
		//함북
		case "hb2" : jimyung = "함경북도"; break;
		//함남
		case "hn2" : jimyung = "함경남도"; break;
		//세종
		case "sj" : jimyung = "세종특별자치시"; break;
		//대전
		case "dj" : jimyung = "대전광역시"; break;
		//대구
		case "dg" : jimyung = "대구광역시"; break;
		//울산
		case "us" : jimyung = "울산광역시"; break;
		//부산
		case "bs" : jimyung = "부산광역시"; break;
		//광주
		case "kj" : jimyung = "광주광역시"; break;
		//제주
		case "jj" : jimyung = "제주특별자치도"; break;
		//인천
		case "ic" : jimyung = "인천광역시"; break;
		}
		$('.map_up_title_l').text(jimyung);
		$('.gzd-map_select__view').not($('.gzd-map_'+$(this).attr("id"))).hide();
		$('.gzd-map_'+$(this).attr("id")).fadeIn();

		return false;
	});
	
	$('.gzd-map_select__view a').click(function(){
		var bookcate = "GZJ02";
		switch(map){
		//경북
		case "kb" : bookcate = "GZJ03"; break;
		//경남
		case "kn" : bookcate = "GZJ03"; break;
		//전북
		case "jb" : bookcate = "GZJ04"; break;
		//전남
		case "jn" : bookcate = "GZJ04"; break;
		//충북
		case "cb" : bookcate = "GZJ05"; break;
		//충남
		case "cn" : bookcate = "GZJ05"; break;
		//서울
		case "su" : bookcate = "GZJ02"; break;
		//경기
		case "kk" : bookcate = "GZJ02"; break;
		//강원
		case "kw" : bookcate = "GZJ01"; break;
		//황북
		case "hb" : bookcate = "GZJ08"; break;
		//황남
		case "hn" : bookcate = "GZJ08"; break;
		//평양
		case "py" : bookcate = "GZJ06"; break;				
		//평북
		case "pb" : bookcate = "GZJ06"; break;				
		//평남
		case "pn" : bookcate = "GZJ06"; break;
		//양강
		case "yk" : bookcate = "GZJ07"; break;
		//자강
		case "jk" : bookcate = "GZJ06"; break;
		//함북
		case "hb2" : bookcate = "GZJ07"; break;
		//함남
		case "hn2" : bookcate = "GZJ07"; break;
		//세종
		case "sj" : bookcate = "GZJ05"; break;
		//대전
		case "dj" : bookcate = "GZJ05"; break;
		//대구
		case "dg" : bookcate = "GZJ05"; break;
		//울산
		case "us" : bookcate = "GZJ03"; break;
		//부산
		case "bs" : bookcate = "GZJ03"; break;
		//광주
		case "kj" : bookcate = "GZJ04"; break;
		//제주
		case "jj" : bookcate = "GZJ04"; break;
		//인천
		case "ic" : bookcate = "GZJ02"; break;
		}
		$('.map_up_title_r').text($(this).text());
		location.href="/book/list.do?mid=GZD&book_cate="+bookcate+"&toponym="+encodeURI($(this).text());

		return false;
	});
	
	// 소개 tab on/off
	$('.common-tab_toggle li').click(function(){
		$('.common-tab_toggle--view').not($('.cont_'+$(this).attr("id"))).hide();
		$('.cont_'+$(this).attr("id")).show();

		$('.common-tab_toggle li').not($(this)).removeClass('on');
		$(this).addClass('on');	

		return false;
	});
	
});

function fn_login(flag) {
	//screen.width  : 현재 운영체제의 너비
	//screen.height : 현재 운영체제의 높이
	w = 460;    //팝업창의 너비
	h = 270;    //팝업창의 높이

	//중앙위치 구해오기
	LeftPosition=(screen.width-w)/2;
	TopPosition=(screen.height-h)/2;

	window.open("/loginForm.do?flag="+flag, "ImgView", "width=" + w + ", height=" + h + ", top=" + TopPosition + ", left=" + LeftPosition + ", resizable=yes, location=no, menubar=no, scrollbars=no, titlebar=no, toolbar=no");
}

function fn_login_check(flag) {
	if( $('#ul_logout').css("display") == "none" ) { 		
		alert("로그인 정보가 없습니다.\n로그인 후 다시 실행해 주시기 바랍니다.");
		fn_login(flag);
		return false;
	}
	else {
		return true;
	}
}

function fn_booklist(mid, bookcate, focus) {
	location.href="/book/list.do?mid="+mid+"&book_cate="+bookcate+"&focus="+focus;
}	

function goNextMenuK(cate, itemCd, bookCd, kingNm, ord, upd_yn){
	document.ils_frm.cate.value = cate;
	document.ils_frm.item_cd.value = itemCd;
	document.ils_frm.book_cd.value = bookCd;
	document.ils_frm.py_king_nm.value = kingNm;
	if(upd_yn) document.ils_frm.upd_yn.value = upd_yn;
	document.ils_frm.ord.value = ord;
	document.ils_frm.submit();
}

function fn_originalImg(i, b, v, p) {

	document.frmPopViewer.item_cd.value = i;
	document.frmPopViewer.book_cd.value = b;
	document.frmPopViewer.vol_no.value = v;
	document.frmPopViewer.page_no.value = p;
	document.frmPopViewer.add_page_no.value = '';
	
	var pages = p.split('_');
	if(pages.length == 2){
		document.frmPopViewer.page_no.value = pages[0];
		document.frmPopViewer.add_page_no.value = pages[1];
	}
	
	//screen.width  : 현재 운영체제의 너비
	//screen.height : 현재 운영체제의 높이
	w = 1500;    //팝업창의 너비
	h = 960;    //팝업창의 높이

	//중앙위치 구해오기
	LeftPosition=(screen.width-w)/2;
	TopPosition=(screen.height-h)/2;

	window.open("", "ImgView", "width=" + w + ", height=" + h + ", top=" + TopPosition + ", left=" + LeftPosition + ", resizable=yes, location=no, menubar=no, scrollbars=no, titlebar=no, toolbar=no");
	document.frmPopViewer.method = 'POST';
	document.frmPopViewer.action = '/pf01/rendererImg.do';
	document.frmPopViewer.target = 'ImgView';
	document.frmPopViewer.submit();
	document.frmPopViewer.target = '';
}

function fn_originalImgGzd(i, b, v, p, img, t, m) {
	
	document.frmPopViewer.item_cd.value = i;
	document.frmPopViewer.book_cd.value = b;
	document.frmPopViewer.vol_no.value = (v == null || v == 'null' ||typeof v == 'undefined' || v == undefined) ? '' : v;
	document.frmPopViewer.page_no.value = (p == null || p == 'null' ||typeof p == 'undefined' || p == undefined) ? '' : p;
	document.frmPopViewer.imgFileNm.value = (img == null || img == 'null' ||typeof img == 'undefined' || img == undefined) ? '' : img;
	document.frmPopViewer.tbl_conts_seq.value = (t == null || t == 'null' ||typeof t == 'undefined' || t == undefined) ? '' : t;
	document.frmPopViewer.mokNm.value = (m == null || m == 'null' ||typeof m == 'undefined' || m == undefined) ? '' : m;
	
	//screen.width  : 현재 운영체제의 너비
	//screen.height : 현재 운영체제의 높이
	w = 1500;    //팝업창의 너비
	h = 960;    //팝업창의 높이

	//중앙위치 구해오기
	LeftPosition=(screen.width-w)/2;
	TopPosition=(screen.height-h)/2;

	window.open("", "ImgView", "width=" + w + ", height=" + h + ", top=" + TopPosition + ", left=" + LeftPosition + ", resizable=yes, location=no, menubar=no, scrollbars=no, titlebar=no, toolbar=no");
	document.frmPopViewer.method = 'POST';
	document.frmPopViewer.action = '/pf01/rendererImg.do';
	document.frmPopViewer.target = 'ImgView';
	document.frmPopViewer.submit();
	document.frmPopViewer.target = '';
}

function fn_mfPdf(b, v) {
	var book_cd = b;
	var vol_no = (v == null || v == 'null' ||typeof v == 'undefined' || v == undefined) ? '' : v;

	window.open("/book/mfPdf.do?book_cd="+book_cd+"&vol_no="+vol_no, "KyuMfPdfView");
}

